//U1T2 - Cadenas - Salvador Muñoz Cordero

//Variables
var cadena1 = "Hola";
var cadena2 = "7";
var cadena3 = "13";
var cadena4 = "Adios";

//Mensajes mostrando el valor de las variables
alert("frase uno");
alert(cadena1 + "\n" + cadena4);
alert(cadena2+cadena3);
alert(cadena1+cadena2+cadena3+cadena4);
alert("Número hexadecimal" + hexadecimal);