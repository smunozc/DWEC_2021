//U1T1 - Números Salvador Muñoz Cordero

//Variables
var entero = 1357;
var decimal = 1357.0;
var cientifico = 135e7;
var octal = 01357;
var hexadecimal = 0x1357;

//Mensajes mostrando el valor de las variables
alert("Número entero" + entero);
alert("Número decimal" + decimal);
alert("Número cientifico" + cientifico);
alert("Número octal" + octal);
alert("Número hexadecimal" + hexadecimal);